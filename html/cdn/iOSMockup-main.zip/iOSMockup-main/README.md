

<h1 align="center">
  <br>
  <a href="http://github.com/MatejaSrejic/iOSMockup"><img src="https://img.icons8.com/color/452/ios-logo.png" alt="iOS Mockup" width="200"></a>
  <br>
  Web iOS Mockup
  <br>
</h1>

<h4 align="center">A minimal iOS UI built in plain HTML and CSS, using SVGs and a few PNGs. Created by Mateja and <a href="http://github.com/YaBoiMarkoDev/iOS14Mockup">YaBoiMarkoDev</a></p></h4>
<p align="center"><font size="1">Kind of hard-coded, and not responsive on small screens, but let's not talk about that. :)</font></p>
